## Custom URL To Merge Accounts Standard Page
Salesforce Custom URL Redirect with Parameters to Merge Accounts

I wrote and Idea in Salesforce but couldn't wait till Salesforce will create this kind of tool so thought about sharing it online to get help in coding and get this kinda awsome tool to work as imaging. 

Those are few functions I am planning to add a bit by bit.. any new ideas will be gladly accepted..

- Select which fields of a certain object to base on when looking for similar records for merge.
- Standard Salesforce merge tool should work with custom objects too.
- Flexible & Custmizable way to Define the logic to locate Duplicate Records (Similar to Duplicate Record Set tool - fuzzy search).
- the Duplicate Search Results should be customizable - allow to customize the list columns.
- Limit of number of records that can be merge in this kind of a tool should be way more than 3.
- a nice function can be if a slight manipulation of data will be allowed on merge - such as merging 2 fields to one master sometimes you need to Save PriorRecordValue + MasterRecordValue.

https://success.salesforce.com/ideaView?id=08730000000Dno4AAC
